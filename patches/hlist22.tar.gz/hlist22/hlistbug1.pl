#!/usr/bin/perl -w

use strict;
use Tk;
use Tk::HList;

my @entry;

my $main = MainWindow->new();

my $hlist = $main->Scrolled('HList',-header=>'1',
                                    -scrollbars=>'osoe')
                                   
->pack(-fill=>'both',-padx=>'3',-pady=>'3');

$hlist->focus;

$hlist->header('create','0',-text=>"Entry");

for (1..10)
{
  $entry[$_] = $hlist->Entry();
  $entry[$_]->insert('end',"entry" . $_);

  $hlist->add($_);
  $hlist->itemCreate($_,'0',-itemtype=>'window',-widget=>$entry[$_]);
}

MainLoop;

